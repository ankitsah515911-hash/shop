// --- DATABASE / SHOPIFY PRODUCT OBJECT SIMULATION ---
// Yahan tum jitne marzi chahe products badha sakte ho!
const apparelProducts = [
    { id: "a1", title: "Gulabi Cotton Anarkali Set", price: "₹6,500 INR", img: "https://images.unsplash.com/photo-1596783074918-c84cb06531ca?auto=format&fit=crop&w=500&q=80", desc: "A pure premium cotton set with traditional block prints and flawless dynamic flow." },
    { id: "a2", title: "Handcrafted Ivory Silk Corset", price: "₹4,200 INR", img: "https://images.unsplash.com/photo-1617627143750-d86bc21e42bb?auto=format&fit=crop&w=500&q=80", desc: "Modern structured silhouette blended perfectly with classical heritage fabrics." },
    { id: "a3", title: "Mogra Linen Summer Dress", price: "₹5,100 INR", img: "https://images.unsplash.com/photo-1609357605129-26f69add5d6e?auto=format&fit=crop&w=500&q=80", desc: "Lightweight, breathable, and sustainable linen designed for effortless luxury." },
    { id: "a4", title: "Midnight Organza Saree", price: "₹8,900 INR", img: "https://images.unsplash.com/photo-1610030469983-98e550d6193c?auto=format&fit=crop&w=500&q=80", desc: "Sheer premium organza saree with intricate handwoven zari borders." }
];

const beautyProducts = [
    { id: "b1", title: "Kumkumadi Facial Glow Oil", price: "₹1,850 INR", img: "https://images.unsplash.com/photo-1608248597481-496100c8c836?auto=format&fit=crop&w=500&q=80", desc: "Infused with pure Kashmiri Saffron, this night serum intensely rejuvenates skin tone." },
    { id: "b2", title: "Rose Water Hydrating Mist", price: "₹650 INR", img: "https://images.unsplash.com/photo-1612817288484-6f916006741a?auto=format&fit=crop&w=500&q=80", desc: "Steam-distilled from fresh Kannauj roses to refresh, hydrate, and balance skin pH." },
    { id: "b3", title: "Almond & Honey Body Butter", price: "₹1,200 INR", img: "https://images.unsplash.com/photo-1556228720-195a672e8a03?auto=format&fit=crop&w=500&q=80", desc: "Deeply nourishing body treatment built to cure extreme dryness and provide 24H hydration." },
    { id: "b4", title: "Herbal Hair Vitalizer Serum", price: "₹1,450 INR", img: "https://images.unsplash.com/photo-1601049541289-9b1b7bbbfe19?auto=format&fit=crop&w=500&q=80", desc: "A powerful combination of Bhringraj and Amla to stimulate roots and restore hair shine." }
];

let cartCount = 0;

document.addEventListener("DOMContentLoaded", () => {
    const apparelGrid = document.getElementById("apparel-grid");
    const beautyGrid = document.getElementById("beauty-grid");
    
    // 1. Inject Apparel Products dynamically
    apparelProducts.forEach(product => {
        apparelGrid.innerHTML += createProductCard(product);
    });

    // 2. Inject Beauty Products dynamically
    beautyProducts.forEach(product => {
        beautyGrid.innerHTML += createProductCard(product);
    });

    // Setup Event Listeners for Dynamic "Shop Now" Buttons
    setupShopNowListeners();
});

// Helper function to build Product Grid UI
function createProductCard(product) {
    return `
        <div class="product-card" data-id="${product.id}">
            <div class="product-image-wrapper">
                <img src="${product.img}" alt="${product.title}">
                <div class="shop-now-btn">Shop Now</div>
            </div>
            <div class="product-info">
                <div class="product-title">${product.title}</div>
                <div class="product-price">${product.price}</div>
            </div>
        </div>
    `;
}

// 3. SHOPIFY MODAL LOGIC (Dating / Detail handling)
function setupShopNowListeners() {
    const modal = document.getElementById("product-modal");
    const closeModal = document.querySelector(".close-modal");
    
    // Catch click on any "Shop Now" button dynamically
    document.addEventListener("click", (e) => {
        if (e.target.classList.contains("shop-now-btn")) {
            const card = e.target.closest(".product-card");
            const productId = card.getAttribute("data-id");
            
            // Find product details from arrays
            const product = [...apparelProducts, ...beautyProducts].find(p => p.id === productId);
            
            if (product) {
                // Populate dynamic data inside Shopify simulation checkout modal
                document.getElementById("modal-title").innerText = product.title;
                document.getElementById("modal-price").innerText = product.price;
                document.getElementById("modal-img").src = product.img;
                document.getElementById("modal-desc").innerText = product.desc;
                
                // Open modal
                modal.style.display = "flex";
            }
        }
    });

    // Close Modal Events
    closeModal.addEventListener("click", () => modal.style.display = "none");
    window.addEventListener("click", (e) => { if (e.target === modal) modal.style.display = "none"; });

    // Simulate Checkout Routing Click
    document.getElementById("modal-checkout-btn").addEventListener("click", () => {
        const title = document.getElementById("modal-title").innerText;
        const qty = document.getElementById("product-qty").value;
        
        alert(`🛒 Redirecting to Shopify Checkout secure gateway...\nItem: ${title}\nQuantity: ${qty}\n\n(Real setup connects to your custom Shopify subdomain checkout!)`);
        
        // Cart updating logic
        cartCount += parseInt(qty);
        document.getElementById("cart-count").innerText = cartCount;
        modal.style.display = "none";
    });
}